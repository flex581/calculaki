import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";

interface CalculatorCardProps {
  name: string;
  description: string;
  path: string;
  icon?: React.ReactNode;
}

export function CalculatorCard({ name, description, path, icon }: CalculatorCardProps) {
  return (
    <Link href={path}>
      <Card className="hover-elevate active-elevate-2 cursor-pointer transition-all h-full" data-testid={`card-calculator-${path}`}>
        <CardHeader className="space-y-1">
          <div className="flex items-start justify-between gap-2">
            <CardTitle className="text-lg">{name}</CardTitle>
            {icon && <div className="text-primary flex-shrink-0">{icon}</div>}
          </div>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-primary font-medium">
            Acessar <ArrowRight className="ml-1 h-4 w-4" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
