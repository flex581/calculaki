import { Link } from "wouter";
import { Calculator } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t bg-card mt-16">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Calculator className="h-5 w-5 text-primary" />
              <span className="font-bold text-foreground">Calculaki</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Todas as ferramentas online em um só lugar. Simples, rápido e gratuito.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-foreground">Links Úteis</h3>
            <div className="flex flex-col gap-2">
              <Link href="/" data-testid="footer-link-home">
                <span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  Início
                </span>
              </Link>
              <Link href="/sobre" data-testid="footer-link-about">
                <span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  Sobre o site
                </span>
              </Link>
              <Link href="/contato" data-testid="footer-link-contact">
                <span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  Contato
                </span>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-foreground">Legal</h3>
            <div className="flex flex-col gap-2">
              <Link href="/privacidade" data-testid="footer-link-privacy">
                <span className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  Política de Privacidade
                </span>
              </Link>
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            Calculaki © 2025 – Desenvolvido com foco em utilidade e praticidade.
          </p>
        </div>
      </div>
    </footer>
  );
}
