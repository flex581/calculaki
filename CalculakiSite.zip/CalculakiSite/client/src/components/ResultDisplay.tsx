import { Card } from "@/components/ui/card";

interface ResultDisplayProps {
  label: string;
  value: string | number;
  unit?: string;
  className?: string;
}

export function ResultDisplay({ label, value, unit, className = "" }: ResultDisplayProps) {
  return (
    <Card className={`bg-primary/10 border-primary/20 p-6 ${className}`}>
      <div className="text-center">
        <p className="text-sm text-muted-foreground mb-2">{label}</p>
        <p className="text-4xl md:text-5xl font-bold text-primary" data-testid={`result-${label.toLowerCase().replace(/\s+/g, '-')}`}>
          {value}
          {unit && <span className="text-2xl ml-2">{unit}</span>}
        </p>
      </div>
    </Card>
  );
}
