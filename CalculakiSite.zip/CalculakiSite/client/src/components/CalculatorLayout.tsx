import { ReactNode } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CalculatorCard } from "./CalculatorCard";
import { calculators } from "@shared/calculators";
import { useEffect } from "react";

interface CalculatorLayoutProps {
  title: string;
  description: string;
  children: ReactNode;
  explanation: string;
  currentPath: string;
  category: string;
}

export function CalculatorLayout({ 
  title, 
  description, 
  children, 
  explanation,
  currentPath,
  category
}: CalculatorLayoutProps) {
  
  useEffect(() => {
    const fullTitle = `${title} – Calculaki`;
    document.title = fullTitle;
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', description);
    }

    let ogTitle = document.querySelector('meta[property="og:title"]');
    if (!ogTitle) {
      ogTitle = document.createElement('meta');
      ogTitle.setAttribute('property', 'og:title');
      document.head.appendChild(ogTitle);
    }
    ogTitle.setAttribute('content', fullTitle);

    let ogDescription = document.querySelector('meta[property="og:description"]');
    if (!ogDescription) {
      ogDescription = document.createElement('meta');
      ogDescription.setAttribute('property', 'og:description');
      document.head.appendChild(ogDescription);
    }
    ogDescription.setAttribute('content', description);

    let ogUrl = document.querySelector('meta[property="og:url"]');
    if (!ogUrl) {
      ogUrl = document.createElement('meta');
      ogUrl.setAttribute('property', 'og:url');
      document.head.appendChild(ogUrl);
    }
    ogUrl.setAttribute('content', `https://calculaki.com${currentPath}`);

    return () => {
      document.title = 'Calculaki - Calculadoras Online Gratuitas';
    };
  }, [title, description, currentPath]);

  const relatedCalculators = calculators
    .filter(calc => calc.category === category && calc.path !== currentPath)
    .slice(0, 3);

  return (
    <div className="container py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2" data-testid="text-calculator-title">
          {title}
        </h1>
        <p className="text-muted-foreground" data-testid="text-calculator-description">
          {description}
        </p>
      </div>

      <Card className="mb-8">
        <CardContent className="pt-6">
          {children}
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-xl">Como funciona este cálculo</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground leading-relaxed" data-testid="text-explanation">
            {explanation}
          </p>
        </CardContent>
      </Card>

      {relatedCalculators.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-4">
            Outras calculadoras que você pode gostar
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {relatedCalculators.map((calc) => (
              <CalculatorCard
                key={calc.id}
                name={calc.name}
                description={calc.description}
                path={calc.path}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
